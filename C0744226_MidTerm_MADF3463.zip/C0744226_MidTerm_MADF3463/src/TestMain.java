public class TestMain
{
    public static void main(String[] args) {

        // this is object creation for class LambtonStringTools which calling methods inside the class


        LambtonStringTools Lambton = new LambtonStringTools();


        Lambton.Reverse();

        Lambton.BinaryToDecimal();

        Lambton.replaceSubString();

        Lambton.MostFrequent();

        Lambton.Initials();
    }
}