import java.util.Scanner;
import  java.util.*;

class LambtonStringTools
{

    //  THIS IS FIRST METHOD TO REVERSE THE STRING


    public void Reverse()
    {
        String Original ="";
        String Reverse = "";
        Scanner in = new Scanner(System.in);

        System.out.println("Enter a string to reverse = ");
        Original = in.nextLine();

        int length = Original.length();

        for ( int i = length - 1 ; i >= 0 ; i-- )
            Reverse = Reverse + Original.charAt(i);

        System.out.println("Reverse of entered string is: "+ Reverse);

       System.out.println("");
       System.out.println("");
    }


    // ============

    // THIS IS THE SECOND METHOD TO REPLACE THE WITH THAT

    public void replaceSubString() {
        String Name;
        String ModifiedName = "";

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a name to Modify with starting String 'the' =");
        Name = sc.nextLine();
/*
        if( Name == "")
        {
            System.out.println("J.K.Rowling");
        }

        System.out.println("after modifying = "+ ModifiedName);

*/

        //  String str = new String("the dog jumped over the fence");
        Name = new String(Name);
        System.out.print("String after replacing 'the' with 'that' :=  " );
        System.out.println("");
        System.out.println(Name.replace("the", "that"));

    }


    //================



// THIS IS THE METHOD TO CONVERT BINARY INTO DECIMAL

    public  void BinaryToDecimal(){




    }

    private void BinaryMethod() {
    }

    public static int BinaryMethod (String str){
        double j = 0;


        // Scanner sc = new Scanner(System.in);
        // str = sc.nextLine();

        for (int i = 0; i < str.length(); i++)
        {
            if (str.charAt(i) == '1')
            {
                j = j + Math.pow(2, str.length() - 1 - i);
            }


        }
        return (int) j;
    }



    // this is most frequent finder





    public void MostFrequent() {

    String str= "";

// to enter char's from keyboard ...


        System.out.println("enter the CHaracters from where you want to find most frequent");
    Scanner Most = new Scanner(System.in);
    str = Most.nextLine();



    if(highestOccuredChar(str) != ' ')
        System.out.println("Most Frequently occured Character ==>  " +Character.toString(highestOccuredChar(str)));
    else
        System.out.println("The String doesn't have any character whose occurance is more than 1");
}

    private static char highestOccuredChar(String str) {

        int[] count = new int[256];

        for (int i = 0; i < str.length(); i++) {
            count[str.charAt(i)]++;
        }

        int max = -1;
        char result = ' ';

        for (int j = 0; j < str.length(); j++) {
            if (max < count[str.charAt(j)] && count[str.charAt(j)] > 1) {
                max = count[str.charAt(j)];
                result = str.charAt(j);
            }
        }

        return result;

    }



    // initials

    public void Initials() {

        String[] s1 = new String[20];
        s1[0] = "D";
        s1[1] = "I";
        s1[2] = "L";
        s1[3] = "J";
        s1[4] = "I";
        s1[5] = "T";
        s1[6] = "";
        s1[7] = "S";
        s1[8] = "I";
        s1[9] = "N";
        s1[10] = "G";
        s1[11] = "H";
        s1[12] = " ";
        s1[13] = "PUREWAL";
        s1[14] = "U";
        s1[15] = "R";
        s1[16] = "E";
        s1[17] = "W";
        s1[18] = "A";
        s1[19] = "L";

        System.out.println("");
        System.out.println("");

        System.out.println(s1[0] + "." + s1[7] +"."+ s1[13]);

        //or

        //System.out.println(s1.charAt[0] + s1.charAt[7]);

    }
}




